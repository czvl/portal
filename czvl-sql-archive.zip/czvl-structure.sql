-- phpMyAdmin SQL Dump
-- version 3.5.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 18, 2014 at 06:25 PM
-- Server version: 5.1.73
-- PHP Version: 5.6.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `czvl`
--

-- --------------------------------------------------------

--
-- Table structure for table `cv_list`
--

CREATE TABLE IF NOT EXISTS `cv_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `internal_num` char(4) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `gender` enum('m','f','u') NOT NULL DEFAULT 'm',
  `marital_status` int(1) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `contact_phone` varchar(15) DEFAULT NULL,
  `other_contacts` text,
  `email` varchar(255) DEFAULT NULL,
  `education` int(1) NOT NULL DEFAULT '1',
  `eduction_info` text,
  `work_experience` text,
  `skills` text,
  `summary` text,
  `salary` varchar(255) DEFAULT NULL,
  `desired_position` varchar(255) DEFAULT NULL,
  `documents` text,
  `applicant_type` text COMMENT 'Діяльність на Майдані / Внутрішні переселенці',
  `cv_file` varchar(255) DEFAULT NULL,
  `recruiter_id` int(11) DEFAULT NULL,
  `recruiter_comments` text,
  `who_filled` varchar(255) DEFAULT 'претендент',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added_time` datetime NOT NULL,
  `status` int(3) DEFAULT '0',
  `is_active` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`),
  KEY `category_id` (`gender`),
  KEY `recruiter_id` (`recruiter_id`),
  KEY `first_name` (`first_name`),
  KEY `last_name` (`last_name`),
  KEY `gender` (`gender`),
  KEY `birth_date` (`birth_date`),
  KEY `education` (`education`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3526 ;

-- --------------------------------------------------------

--
-- Table structure for table `cv_statuses`
--

CREATE TABLE IF NOT EXISTS `cv_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cv_id` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `added_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  KEY `cv_id` (`cv_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2965 ;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_assistance`
--

CREATE TABLE IF NOT EXISTS `cv_to_assistance` (
  `cv_id` int(11) NOT NULL,
  `assistance_type_id` int(1) NOT NULL,
  PRIMARY KEY (`cv_id`,`assistance_type_id`),
  KEY `assistance_type_id` (`assistance_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_category`
--

CREATE TABLE IF NOT EXISTS `cv_to_category` (
  `cv_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`cv_id`,`category_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_driver_license`
--

CREATE TABLE IF NOT EXISTS `cv_to_driver_license` (
  `cv_id` int(11) NOT NULL,
  `license_id` int(1) NOT NULL,
  PRIMARY KEY (`cv_id`,`license_id`),
  KEY `license_id` (`license_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_job_location`
--

CREATE TABLE IF NOT EXISTS `cv_to_job_location` (
  `cv_id` int(11) NOT NULL,
  `city_id` char(5) NOT NULL,
  PRIMARY KEY (`cv_id`,`city_id`),
  KEY `city_id` (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_position`
--

CREATE TABLE IF NOT EXISTS `cv_to_position` (
  `cv_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`cv_id`,`position_id`),
  KEY `position_id` (`position_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cv_to_residence`
--

CREATE TABLE IF NOT EXISTS `cv_to_residence` (
  `cv_id` int(11) NOT NULL,
  `city_id` char(5) NOT NULL,
  PRIMARY KEY (`cv_id`,`city_id`),
  KEY `city_id` (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `action_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`action_time`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `role` varchar(100) NOT NULL DEFAULT '1',
  `signin_time` datetime NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `password` (`password`,`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=136 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
